from database import db

class SIMCard(db.Model):
    sim_number = db.Column(db.String, primary_key=True)
    phone_number = db.Column(db.String, nullable=False)
    status = db.Column(db.String, default='inactive')
    activation_date = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f"<SIMCard {self.sim_number}>"
